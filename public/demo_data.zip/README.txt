# TicknTie_Project_2025-10-05T17-34-14

## Contents
- workbook.xlsx: The main spreadsheet with evidence references (Excel-compatible)
- evidence/: Folder containing all attached evidence files

## Evidence Files
This project contains 27 evidence files.

## Instructions
1. Extract this ZIP file to a folder
2. Open workbook.xlsx in Excel or any spreadsheet application
3. Evidence files are referenced in cells with 📌 markers
4. View evidence files in the evidence/ folder

## Created
10/5/2025, 12:34:14 PM

## Created with
TicknTie - Open source audit evidence management
https://github.com/rp4/tick_n_tie
